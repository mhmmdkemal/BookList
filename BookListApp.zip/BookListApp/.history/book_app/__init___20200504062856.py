.striker{
    text-decoration: line-through;
}