from django.apps import AppConfig


class BookListConfig(AppConfig):
    name = 'book_list'
